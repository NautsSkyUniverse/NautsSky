
import { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { cn } from "@/lib/utils";
import { Building, Cookie, Menu, X } from "lucide-react";

const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const location = useLocation();

  // Detect if page is scrolled
  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 10) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  // Close mobile menu when changing routes
  useEffect(() => {
    setIsMobileMenuOpen(false);
  }, [location]);

  const isCookieNautsPage = location.pathname === "/cookienauts";

  return (
    <nav
      className={cn(
        "fixed top-0 left-0 right-0 z-50 transition-all duration-300",
        isScrolled
          ? isCookieNautsPage 
            ? "bg-nauts-paper/90 text-nauts-darkbrown shadow-md backdrop-blur-md"
            : "glass-effect shadow-md"
          : isCookieNautsPage
            ? "bg-transparent text-nauts-darkbrown"
            : "bg-transparent"
      )}
    >
      <div className="container mx-auto px-4 md:px-8">
        <div className="flex h-16 items-center justify-between">
          {/* Logo */}
          <Link
            to="/"
            className="flex items-center space-x-2 transition-transform duration-300 hover:scale-105"
          >
            {isCookieNautsPage ? (
              <Cookie className="h-7 w-7 text-nauts-darkbrown" />
            ) : (
              <Building className="h-7 w-7" />
            )}
            <span className={cn(
              "text-xl font-bold tracking-tight",
              isCookieNautsPage ? "font-spectral" : "font-playfair"
            )}>
              {isCookieNautsPage ? "CookieNauts" : "NautsSky"}
            </span>
          </Link>

          {/* Desktop menu */}
          <div className="hidden md:flex md:items-center md:space-x-8">
            <Link
              to="/"
              className={cn(
                "relative font-medium transition-colors hover:text-primary",
                location.pathname === "/" ? "text-primary after:absolute after:-bottom-1 after:left-0 after:h-0.5 after:w-full after:bg-primary" : "text-muted-foreground",
                isCookieNautsPage ? "hover:text-nauts-darkbrown" : ""
              )}
            >
              Home
            </Link>
            <Link
              to="/cookienauts"
              className={cn(
                "group relative font-medium transition-colors",
                location.pathname === "/cookienauts" ? "text-nauts-darkbrown after:absolute after:-bottom-1 after:left-0 after:h-0.5 after:w-full after:bg-nauts-darkbrown" : "text-muted-foreground hover:text-primary",
                isCookieNautsPage ? "hover:text-nauts-darkbrown" : ""
              )}
            >
              <span className="flex items-center gap-1.5">
                CookieNauts
                <Cookie className={cn(
                  "h-4 w-4 transition-transform duration-300",
                  "group-hover:rotate-12"
                )} />
              </span>
            </Link>
          </div>

          {/* Mobile menu button */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="md:hidden"
            aria-label="Toggle menu"
          >
            {isMobileMenuOpen ? (
              <X className={cn(
                "h-6 w-6 transition-colors",
                isCookieNautsPage ? "text-nauts-darkbrown" : ""
              )} />
            ) : (
              <Menu className={cn(
                "h-6 w-6 transition-colors",
                isCookieNautsPage ? "text-nauts-darkbrown" : ""
              )} />
            )}
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      {isMobileMenuOpen && (
        <div className={cn(
          "absolute left-0 right-0 z-20 px-4 py-6 shadow-lg transition-all md:hidden",
          isCookieNautsPage ? "bg-nauts-paper text-nauts-darkbrown" : "glass-effect"
        )}>
          <div className="flex flex-col space-y-4">
            <Link
              to="/"
              className={cn(
                "p-2 font-medium",
                location.pathname === "/" ? "font-semibold" : ""
              )}
            >
              Home
            </Link>
            <Link
              to="/cookienauts"
              className={cn(
                "flex items-center gap-2 p-2 font-medium",
                location.pathname === "/cookienauts" ? "font-semibold" : ""
              )}
            >
              CookieNauts
              <Cookie className="h-4 w-4" />
            </Link>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
