
import { cn } from "@/lib/utils";
import { Building, Cookie, ArrowRightCircle } from "lucide-react";
import { Link } from "react-router-dom";

interface HeroSectionProps {
  title: string;
  subtitle: string;
  type: "nautssky" | "cookienauts";
  ctaText?: string;
  ctaLink?: string;
}

const HeroSection = ({ title, subtitle, type, ctaText, ctaLink }: HeroSectionProps) => {
  const isCookieNauts = type === "cookienauts";

  return (
    <section className={cn(
      "relative flex min-h-[85vh] items-center justify-center overflow-hidden px-4",
      isCookieNauts ? "bg-paper-texture" : "bg-gradient-to-b from-white to-slate-50"
    )}>
      {/* Background decorative elements */}
      {!isCookieNauts && (
        <>
          <div className="absolute top-1/4 -left-20 h-56 w-56 rounded-full bg-blue-500/5 blur-3xl"></div>
          <div className="absolute bottom-1/4 -right-20 h-72 w-72 rounded-full bg-purple-500/5 blur-3xl"></div>
        </>
      )}

      {/* Main content */}
      <div className="container relative z-10 mx-auto max-w-6xl">
        <div className="text-center">
          {/* Icon */}
          <div className="mx-auto mb-6 inline-flex rounded-full p-2">
            {isCookieNauts ? (
              <Cookie className="mx-auto h-16 w-16 text-nauts-darkbrown" />
            ) : (
              <Building className="mx-auto h-16 w-16 text-primary/90" />
            )}
          </div>

          {/* Title */}
          <h1 className={cn(
            "mb-6 animate-fade-up text-center text-5xl font-bold tracking-tight md:text-6xl lg:text-7xl",
            isCookieNauts 
              ? "font-spectral text-nauts-darkbrown" 
              : "font-playfair text-gray-900"
          )}>
            {title}
          </h1>

          {/* Subtitle */}
          <p className={cn(
            "mx-auto mb-10 max-w-3xl animate-fade-up text-xl opacity-90 md:text-2xl",
            isCookieNauts 
              ? "font-spectral text-nauts-brown" 
              : "text-gray-600"
          )} style={{ animationDelay: "200ms" }}>
            {subtitle}
          </p>

          {/* CTA Button */}
          {ctaText && ctaLink && (
            <div className="mt-8 animate-fade-up" style={{ animationDelay: "400ms" }}>
              <Link 
                to={ctaLink}
                className={cn(
                  "group inline-flex items-center gap-2 rounded-full px-6 py-3 font-medium shadow-md transition-all duration-300",
                  isCookieNauts 
                    ? "bg-nauts-darkbrown text-nauts-paper hover:bg-nauts-brown" 
                    : "bg-primary text-white hover:bg-primary/90"
                )}
              >
                {ctaText}
                <ArrowRightCircle className="h-5 w-5 transition-transform duration-300 group-hover:translate-x-1" />
              </Link>
            </div>
          )}
        </div>
      </div>

      {/* Decorative dots/elements for CookieNauts */}
      {isCookieNauts && (
        <div className="absolute top-1/3 right-1/4 flex space-x-2">
          {[...Array(5)].map((_, i) => (
            <div key={i} className="h-2 w-2 rounded-full bg-nauts-darkbrown/70"></div>
          ))}
        </div>
      )}
    </section>
  );
};

export default HeroSection;
