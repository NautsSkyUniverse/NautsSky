
import { useState } from "react";
import { Check, Mail } from "lucide-react";
import { cn } from "@/lib/utils";

const JobApplication = () => {
  const [isHovered, setIsHovered] = useState(false);

  const qualifications = [
    "Exceptional Customer Service",
    "Efficiency & Multitasking",
    "Product Knowledge",
    "Professionalism & Cleanliness"
  ];

  return (
    <div className="w-full rounded-3xl bg-nauts-darkbrown p-6 md:p-10">
      <div className="mb-8 text-center">
        <h2 className="mb-2 font-spectral text-5xl font-bold text-nauts-paper md:text-6xl">
          WE ARE 
          <span className="block">HIRING</span>
        </h2>
        <div className="mx-auto mt-4 max-w-md">
          <a
            href="#apply"
            className="group relative block w-full overflow-hidden rounded-full bg-nauts-paper/20 p-4 text-center font-spectral text-xl font-medium text-nauts-paper transition-all duration-300 hover:bg-nauts-paper/30"
            onMouseEnter={() => setIsHovered(true)}
            onMouseLeave={() => setIsHovered(false)}
          >
            <span className="relative z-10">Join Our Team at Cookie Nauts!</span>
            <span 
              className={cn(
                "absolute bottom-0 left-0 h-0.5 w-full bg-nauts-paper/60 transition-all duration-700",
                isHovered ? "scale-x-100" : "scale-x-0"
              )} 
            />
          </a>
        </div>
      </div>

      <div className="mb-6 text-center">
        <h3 className="mb-4 border-y border-nauts-paper/20 py-2 font-spectral text-2xl font-medium uppercase tracking-wider text-nauts-paper">
          WAITER/WAITRESS
        </h3>
      </div>

      <div className="mb-8 text-nauts-paper">
        <p className="mb-4 font-spectral text-lg leading-relaxed">
          Are you ready to contribute to a thriving and innovative company? 
          Come join Cookie Nauts and grow with us!
        </p>
      </div>

      <div className="mb-8">
        <div className="mb-6 inline-block rounded-full border border-nauts-paper/30 px-6 py-2">
          <h4 className="font-spectral text-xl uppercase tracking-wider text-nauts-paper">
            QUALIFICATIONS
          </h4>
        </div>

        <ul className="space-y-3">
          {qualifications.map((qualification, index) => (
            <li 
              key={index} 
              className="flex items-center space-x-3 text-nauts-paper opacity-0 animate-fade-up"
              style={{ animationDelay: `${index * 150}ms`, animationFillMode: 'forwards' }}
            >
              <div className="flex h-6 w-6 items-center justify-center rounded-full border border-nauts-paper/50">
                <Check className="h-4 w-4" />
              </div>
              <span className="font-spectral text-lg">{qualification}</span>
            </li>
          ))}
        </ul>
      </div>

      <div className="mt-8 rounded-xl bg-nauts-brown/50 p-5">
        <div className="flex flex-col items-center justify-between space-y-4 sm:flex-row sm:space-y-0">
          <div className="flex items-center space-x-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-full border border-nauts-paper">
              <Mail className="h-6 w-6 text-nauts-paper" />
            </div>
            <div>
              <p className="font-spectral text-sm text-nauts-paper/70">Join Us — Send Resume.</p>
              <p className="font-spectral text-lg text-nauts-paper">cookienauts.co@gmail.com</p>
            </div>
          </div>
          
          <a
            href="mailto:cookienauts.co@gmail.com"
            className="rounded-lg bg-nauts-paper px-6 py-3 font-medium text-nauts-darkbrown transition-transform hover:scale-105"
            id="apply"
          >
            APPLY NOW
          </a>
        </div>
      </div>
    </div>
  );
};

export default JobApplication;
