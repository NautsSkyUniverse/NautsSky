
import { useState } from "react";
import { User, Mail, Briefcase, ArrowRight } from "lucide-react";
import { cn } from "@/lib/utils";

interface TeamMemberProps {
  name: string;
  position: string;
  email: string;
  bio: string;
  imageUrl: string;
  index: number;
}

const TeamMember = ({ name, position, email, bio, imageUrl, index }: TeamMemberProps) => {
  const [isHovered, setIsHovered] = useState(false);

  // Alternate animation direction for even/odd indices
  const animationClass = index % 2 === 0 ? "animate-slide-in-left" : "animate-slide-in-right";
  const delay = `delay-[${index * 100}ms]`;

  return (
    <div 
      className={cn(
        "group relative overflow-hidden rounded-xl transition-all duration-500",
        animationClass,
        delay,
        isHovered ? "shadow-xl" : "shadow-md"
      )}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className="relative h-full bg-white">
        {/* Card content */}
        <div className="flex flex-col md:flex-row">
          {/* Image */}
          <div className="relative h-60 overflow-hidden md:h-auto md:w-40 lg:w-56">
            <div 
              className="absolute inset-0 bg-cover bg-center transition-transform duration-700 ease-out"
              style={{ backgroundImage: `url(${imageUrl})` }}
            ></div>
            <div className="absolute inset-0 bg-black/5"></div>
          </div>

          {/* Info */}
          <div className="flex flex-1 flex-col justify-between p-6">
            <div className="mb-4">
              <h3 className="mb-1 font-playfair text-xl font-semibold tracking-tight text-gray-900">{name}</h3>
              <div className="flex items-center text-sm text-muted-foreground">
                <Briefcase className="mr-2 h-4 w-4" />
                {position}
              </div>
            </div>

            <div className="space-y-3">
              <p className="line-clamp-3 text-sm text-gray-600">{bio}</p>
              
              <div className="pt-3">
                <div className="flex items-center text-sm text-muted-foreground hover:text-primary">
                  <Mail className="mr-2 h-4 w-4" />
                  <a href={`mailto:${email}`} className="hover:underline">{email}</a>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Hover overlay */}
        <div className={cn(
          "absolute bottom-0 right-0 p-4 transition-transform duration-300",
          isHovered ? "translate-y-0" : "translate-y-full"
        )}>
          <div className="rounded-full bg-primary p-2 text-white shadow-lg transition-transform duration-300 hover:scale-110">
            <ArrowRight className="h-4 w-4" />
          </div>
        </div>
      </div>
    </div>
  );
};

export default TeamMember;
