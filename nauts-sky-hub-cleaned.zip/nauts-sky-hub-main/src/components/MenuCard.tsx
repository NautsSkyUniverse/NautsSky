
import { useState } from "react";
import { cn } from "@/lib/utils";

interface MenuCardProps {
  name: string;
  price: string;
  image: string;
  delay?: number;
}

const MenuCard = ({ name, price, image, delay = 0 }: MenuCardProps) => {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <div 
      className={cn(
        "cookie-card bg-nauts-paper/80 opacity-0",
        "animate-fade-in"
      )}
      style={{ animationDelay: `${delay}ms`, animationFillMode: 'forwards' }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className="p-4 text-center">
        <div className="mx-auto mb-3 h-36 w-36 overflow-hidden rounded-full">
          <img 
            src={image} 
            alt={name} 
            className={cn(
              "h-full w-full object-cover transition-transform duration-700",
              isHovered ? "scale-110" : "scale-100"
            )}
          />
        </div>
        <h3 className="mb-1 font-spectral text-xl font-semibold tracking-wide text-nauts-darkbrown">{name}</h3>
        <p className="font-spectral text-lg text-nauts-brown">${price}</p>
      </div>
    </div>
  );
};

export default MenuCard;
