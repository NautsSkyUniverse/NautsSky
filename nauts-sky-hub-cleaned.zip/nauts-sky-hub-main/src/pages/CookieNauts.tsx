
import { useEffect } from "react";
import { cn } from "@/lib/utils";
import HeroSection from "@/components/HeroSection";
import MenuCard from "@/components/MenuCard";
import JobApplication from "@/components/JobApplication";
import { Phone, Mail, ArrowUpCircle } from "lucide-react";

// Cookie menu data
const cookies = [
  { name: "Bloody Marry's", price: "2.3", image: "https://images.unsplash.com/photo-1558961363-fa8fdf82db35?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400&q=80" },
  { name: "Warner Peanut's", price: "1.8", image: "https://images.unsplash.com/photo-1590080875515-8a3a8dc5735e?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400&q=80" },
  { name: "Cramberry", price: "3.5", image: "https://images.unsplash.com/photo-1596023070633-7d4e3c2182c7?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400&q=80" },
  { name: "Dulce de Leche", price: "2.2", image: "https://images.unsplash.com/photo-1499636136210-6f4ee915583e?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400&q=80" },
  { name: "S'more Cookies", price: "2.4", image: "https://images.unsplash.com/photo-1590080874088-eec64895b423?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400&q=80" },
  { name: "Dulce de Leche", price: "2.3", image: "https://images.unsplash.com/photo-1598839950984-034f6dc7b2a8?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400&q=80" },
  { name: "Pearl Balls", price: "2.3", image: "https://images.unsplash.com/photo-1614145121029-83a9f7b68bf4?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400&q=80" },
  { name: "Butter & Salty", price: "2.1", image: "https://images.unsplash.com/photo-1599599810769-bcde5a160d32?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400&q=80" },
  { name: "Green Flore", price: "2.2", image: "https://images.unsplash.com/photo-1618923850107-d1a234d7a73a?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400&q=80" },
];

// Drink menu data
const drinks = [
  { name: "Cuddel Cup", price: "4.50" },
  { name: "Sweet Nuzzle", price: "5.00" },
  { name: "Matcha Vista", price: "5.50" },
];

const CookieNauts = () => {
  // Scroll to top button functionality
  useEffect(() => {
    const handleScroll = () => {
      const scrollToTopBtn = document.getElementById("scrollToTopBtn");
      if (scrollToTopBtn) {
        if (window.scrollY > 300) {
          scrollToTopBtn.classList.remove("opacity-0", "pointer-events-none");
          scrollToTopBtn.classList.add("opacity-100");
        } else {
          scrollToTopBtn.classList.remove("opacity-100");
          scrollToTopBtn.classList.add("opacity-0", "pointer-events-none");
        }
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: "smooth"
    });
  };

  return (
    <div className="min-h-screen bg-paper-texture bg-cover">
      {/* Hero Section */}
      <HeroSection 
        title="Cookie Nauts"
        subtitle="Artisanal cookies crafted with premium ingredients and innovative flavors."
        type="cookienauts"
        ctaText="Explore Menu"
        ctaLink="#menu"
      />

      {/* Menu Section */}
      <section id="menu" className="py-20">
        <div className="container mx-auto px-4 md:px-8">
          <div className="mb-16 text-center">
            <h2 className="mb-6 font-spectral text-4xl font-bold text-nauts-darkbrown md:text-5xl">
              Our Cookie Menu
            </h2>
            <p className="mx-auto max-w-2xl font-spectral text-xl text-nauts-brown">
              Explore our delicious selection of hand-crafted cookies made with love and premium ingredients.
            </p>
          </div>

          {/* Cookies Grid */}
          <div className="mb-20 grid grid-cols-1 gap-6 sm:grid-cols-2 md:grid-cols-3">
            {cookies.map((cookie, index) => (
              <MenuCard
                key={`${cookie.name}-${index}`}
                name={cookie.name}
                price={cookie.price}
                image={cookie.image}
                delay={index * 100}
              />
            ))}
          </div>

          {/* Drinks Section */}
          <div className="mx-auto mb-10 max-w-md rounded-xl border-2 border-nauts-brown/30 bg-nauts-cream/80 p-8">
            <h3 className="mb-6 text-center font-spectral text-2xl font-bold text-nauts-darkbrown">
              DRINK & LATTE
            </h3>
            <div className="space-y-4">
              {drinks.map((drink, index) => (
                <div 
                  key={drink.name} 
                  className="flex items-center justify-between border-b border-dashed border-nauts-brown/30 pb-3 opacity-0 animate-fade-up"
                  style={{ animationDelay: `${index * 150}ms`, animationFillMode: 'forwards' }}
                >
                  <span className="font-spectral text-lg text-nauts-brown">{drink.name}</span>
                  <span className="font-spectral text-lg font-semibold text-nauts-darkbrown">${drink.price}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Hiring Section */}
      <section id="hiring" className="py-20 bg-hiring-texture bg-cover bg-center">
        <div className="container mx-auto px-4 md:px-8">
          <div className="mb-16 text-center">
            <h2 className="mb-6 font-spectral text-4xl font-bold text-nauts-darkbrown md:text-5xl">
              Join Our Team
            </h2>
            <p className="mx-auto max-w-2xl font-spectral text-xl text-nauts-brown">
              We're looking for passionate individuals to join the CookieNauts family.
            </p>
          </div>

          <div className="mx-auto max-w-4xl">
            <JobApplication />
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-16 bg-nauts-darkbrown/95">
        <div className="container mx-auto px-4 md:px-8">
          <div className="flex flex-col items-center justify-between gap-8 text-center md:flex-row md:text-left">
            <div>
              <h2 className="mb-4 font-spectral text-3xl font-bold text-nauts-paper">
                Visit Us
              </h2>
              <p className="mb-2 font-spectral text-lg text-nauts-paper">
                3001 Connecticut Ave NW, Washington.
              </p>
              <p className="font-spectral text-nauts-paper/80">
                Mon-Fri: 8am-8pm | Sat-Sun: 9am-6pm
              </p>
            </div>

            <div className="flex flex-col gap-4 md:flex-row">
              <a
                href="tel:+085280388895"
                className="flex items-center justify-center gap-2 rounded-lg bg-nauts-brown/30 px-5 py-3 font-spectral text-nauts-paper transition-colors hover:bg-nauts-brown/50"
              >
                <Phone className="h-5 w-5" />
                0852-8038-8895
              </a>
              <a
                href="mailto:cookienauts.co@gmail.com"
                className="flex items-center justify-center gap-2 rounded-lg bg-nauts-brown/30 px-5 py-3 font-spectral text-nauts-paper transition-colors hover:bg-nauts-brown/50"
              >
                <Mail className="h-5 w-5" />
                cookienauts.co@gmail.com
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-nauts-darkbrown py-8">
        <div className="container mx-auto px-4 md:px-8">
          <div className="text-center">
            <p className="font-spectral text-sm text-nauts-paper/70">
              &copy; {new Date().getFullYear()} CookieNauts - A NautsSky Venture. All rights reserved.
            </p>
          </div>
        </div>
      </footer>

      {/* Scroll to top button */}
      <button
        id="scrollToTopBtn"
        onClick={scrollToTop}
        className="fixed bottom-6 right-6 z-50 rounded-full bg-nauts-darkbrown p-3 text-white shadow-lg transition-all duration-300 opacity-0 pointer-events-none hover:bg-nauts-brown"
        aria-label="Scroll to top"
      >
        <ArrowUpCircle className="h-6 w-6" />
      </button>
    </div>
  );
};

export default CookieNauts;
