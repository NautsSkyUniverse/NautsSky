
import { useState } from "react";
import { Link } from "react-router-dom";
import { cn } from "@/lib/utils";
import HeroSection from "@/components/HeroSection";
import TeamMember from "@/components/TeamMember";
import { ArrowRight, Cookie, Building, Star } from "lucide-react";

const teamMembers = [
  {
    name: "Sophia Anderson",
    position: "CEO & Founder",
    email: "sophia@nautssky.com",
    bio: "Visionary leader with 15+ years in tech and business development. Founded NautsSky with the mission to create innovative solutions that bridge traditional industries with cutting-edge technology.",
    imageUrl: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-4.0.3&auto=format&fit=crop&w=256&q=80"
  },
  {
    name: "Marcus Chen",
    position: "CTO",
    email: "marcus@nautssky.com",
    bio: "Tech genius with expertise in cloud architecture and AI. Marcus leads our technical strategy and ensures we stay at the forefront of technological innovation.",
    imageUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=256&q=80"
  },
  {
    name: "Aisha Johnson",
    position: "Creative Director",
    email: "aisha@nautssky.com",
    bio: "Award-winning designer passionate about user experience and brand storytelling. Aisha oversees all creative aspects of NautsSky and our subsidiary ventures.",
    imageUrl: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?ixlib=rb-4.0.3&auto=format&fit=crop&w=256&q=80"
  },
  {
    name: "David Park",
    position: "Operations Manager",
    email: "david@nautssky.com",
    bio: "Efficiency expert with a background in logistics and supply chain management. David ensures smooth operations across all NautsSky ventures, including CookieNauts.",
    imageUrl: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-4.0.3&auto=format&fit=crop&w=256&q=80"
  },
  {
    name: "Maya Rodriguez",
    position: "Marketing Director",
    email: "maya@nautssky.com",
    bio: "Strategic marketing professional with experience in both digital and traditional channels. Maya crafts compelling narratives that connect our brands with audiences worldwide.",
    imageUrl: "https://images.unsplash.com/photo-1580489944761-15a19d654956?ixlib=rb-4.0.3&auto=format&fit=crop&w=256&q=80"
  }
];

const Index = () => {
  const [activeTeamFilter, setActiveTeamFilter] = useState("all");

  const filteredTeamMembers = activeTeamFilter === "all" 
    ? teamMembers 
    : teamMembers.filter((_, index) => index < 3);

  return (
    <div className="min-h-screen bg-gradient-to-b from-white via-slate-50 to-white">
      {/* Hero Section */}
      <HeroSection 
        title="NautsSky"
        subtitle="Pioneering the future through innovation, creativity, and excellence in every venture we undertake."
        type="nautssky"
        ctaText="Explore Our Team"
        ctaLink="#team"
      />

      {/* Our Team Section */}
      <section id="team" className="py-20">
        <div className="container mx-auto px-4 md:px-8">
          <div className="mb-16 max-w-3xl">
            <h2 className="mb-6 font-playfair text-4xl font-bold tracking-tight text-gray-900 md:text-5xl">
              Our <span className="text-primary">Team</span>
            </h2>
            <p className="text-xl text-gray-600">
              Meet the visionaries behind NautsSky, a diverse team of experts dedicated to pushing boundaries and creating exceptional experiences.
            </p>
          </div>

          {/* Team filters */}
          <div className="mb-12 flex flex-wrap gap-2">
            <button
              onClick={() => setActiveTeamFilter("all")}
              className={cn(
                "rounded-full px-6 py-2 text-sm font-medium transition-all",
                activeTeamFilter === "all"
                  ? "bg-primary text-white shadow-md"
                  : "bg-gray-100 text-gray-600 hover:bg-gray-200"
              )}
            >
              All Members
            </button>
            <button
              onClick={() => setActiveTeamFilter("leadership")}
              className={cn(
                "rounded-full px-6 py-2 text-sm font-medium transition-all",
                activeTeamFilter === "leadership"
                  ? "bg-primary text-white shadow-md"
                  : "bg-gray-100 text-gray-600 hover:bg-gray-200"
              )}
            >
              Leadership
            </button>
          </div>

          {/* Team members grid */}
          <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3">
            {filteredTeamMembers.map((member, index) => (
              <TeamMember
                key={member.name}
                name={member.name}
                position={member.position}
                email={member.email}
                bio={member.bio}
                imageUrl={member.imageUrl}
                index={index}
              />
            ))}
          </div>
        </div>
      </section>

      {/* Our Ventures - CookieNauts Feature */}
      <section className="relative overflow-hidden py-20">
        {/* Decorative background */}
        <div className="absolute inset-0 bg-slate-50/80"></div>
        <div className="absolute -right-40 top-20 h-80 w-80 rounded-full bg-blue-100/50 blur-3xl"></div>
        <div className="absolute -left-40 bottom-20 h-80 w-80 rounded-full bg-blue-100/50 blur-3xl"></div>

        <div className="container relative z-10 mx-auto px-4 md:px-8">
          <div className="mb-16 max-w-3xl">
            <h2 className="mb-6 font-playfair text-4xl font-bold tracking-tight text-gray-900 md:text-5xl">
              Our <span className="text-primary">Ventures</span>
            </h2>
            <p className="text-xl text-gray-600">
              Discover the innovative businesses under the NautsSky umbrella, each reflecting our commitment to quality and excellence.
            </p>
          </div>

          {/* CookieNauts Feature */}
          <div className="overflow-hidden rounded-2xl bg-white shadow-xl">
            <div className="flex flex-col md:flex-row">
              {/* Image Section */}
              <div className="relative h-64 overflow-hidden bg-paper-texture bg-cover bg-center md:h-auto md:w-1/2">
                <div className="flex h-full flex-col items-center justify-center p-8 text-center">
                  <Cookie className="mb-4 h-16 w-16 text-nauts-darkbrown" />
                  <h3 className="mb-2 font-spectral text-3xl font-bold text-nauts-darkbrown">Cookie Nauts</h3>
                  <p className="font-spectral text-lg text-nauts-brown">Artisanal cookies with a twist</p>
                </div>
              </div>

              {/* Content Section */}
              <div className="flex flex-1 flex-col justify-between p-8">
                <div>
                  <div className="mb-4 inline-flex items-center rounded-full bg-blue-50 px-3 py-1">
                    <Star className="mr-1 h-4 w-4 text-amber-500" />
                    <span className="text-sm font-medium text-blue-900">Featured Venture</span>
                  </div>
                  <h3 className="mb-4 font-playfair text-2xl font-bold text-gray-900">The Sweet Side of NautsSky</h3>
                  <p className="mb-6 text-gray-600">
                    CookieNauts is our artisanal cookie shop that combines traditional baking techniques with innovative flavors. What started as a small experiment has grown into a beloved brand with a loyal customer base.
                  </p>
                  
                  <div className="mb-8 space-y-3">
                    <div className="flex items-start">
                      <div className="mr-3 mt-1 h-5 w-5 rounded-full bg-amber-100 p-1">
                        <div className="h-3 w-3 rounded-full bg-amber-400"></div>
                      </div>
                      <p className="text-gray-600">Hand-crafted cookies using premium ingredients</p>
                    </div>
                    <div className="flex items-start">
                      <div className="mr-3 mt-1 h-5 w-5 rounded-full bg-amber-100 p-1">
                        <div className="h-3 w-3 rounded-full bg-amber-400"></div>
                      </div>
                      <p className="text-gray-600">Located in the heart of Washington D.C.</p>
                    </div>
                    <div className="flex items-start">
                      <div className="mr-3 mt-1 h-5 w-5 rounded-full bg-amber-100 p-1">
                        <div className="h-3 w-3 rounded-full bg-amber-400"></div>
                      </div>
                      <p className="text-gray-600">Unique menu with rotating seasonal specials</p>
                    </div>
                  </div>
                </div>

                <div className="mt-auto">
                  <Link 
                    to="/cookienauts" 
                    className="group inline-flex items-center font-medium text-primary transition-colors hover:text-primary/80"
                  >
                    Explore CookieNauts
                    <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-white py-12">
        <div className="container mx-auto px-4 md:px-8">
          <div className="flex flex-col items-center justify-between gap-6 md:flex-row">
            <div className="flex items-center">
              <Building className="mr-2 h-6 w-6" />
              <span className="font-playfair text-xl font-semibold">NautsSky</span>
            </div>

            <div className="text-center md:text-right">
              <p className="text-sm text-gray-500">
                &copy; {new Date().getFullYear()} NautsSky. All rights reserved.
              </p>
              <p className="text-sm text-gray-400">
                3001 Connecticut Ave NW, Washington.
              </p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Index;
